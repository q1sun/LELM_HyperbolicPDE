#!/bin/bash
python3 -u main_Exp-Sec311-LinearConvection.py --weights 'Figures/Trained_Model/simulation_0'  --figures 'Figures/Python/simulation_0'
